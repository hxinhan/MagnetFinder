# MagnetFinder
A real-time crawler for searching P2P magnet url.

* version 1.0.1
* coded by HansonHH
* [HomePage](http://hansonhh.github.io/MagnetFinder/)
* Download [Windows](http://hansonhh.github.io/MagnetFinder/) version.
* Download [Linux/Mac OS X](http://hansonhh.github.io/MagnetFinder/) version.

#### For Linux/OS X users:

* Install BeacutifulSoup4 before use MagnetFinder :)
* Example: python MagnetFinder.py

#### For Windows users:

* Execute MagnetFinder.exe
 

